let mealRecords = JSON.parse(localStorage.getItem('mealRecords')) || [];
let exerciseRecords = JSON.parse(localStorage.getItem('exerciseRecords')) || [];
let sleepRecords = JSON.parse(localStorage.getItem('sleepRecords')) || [];
let userData = JSON.parse(localStorage.getItem('userData')) || { weight: null, height: null };

// دالة لتحديث بيانات المستخدم (الوزن والطول)
function setUserData() {
    const weight = parseFloat(document.getElementById('weightInput').value);
    const height = parseFloat(document.getElementById('heightInput').value);

    if (!isNaN(weight) && !isNaN(height)) {
        userData = { weight, height };
        localStorage.setItem('userData', JSON.stringify(userData));
        alert('تم تحديث بياناتك بنجاح!');
        displayDailyStatus();
    } else {
        alert('يرجى إدخال بيانات صحيحة للوزن والطول.');
    }
}

// دالة لإضافة بيانات الوجبات
function addMealData() {
    const mealName = document.getElementById('mealInput').value;
    const proteinAmount = parseFloat(document.getElementById('proteinInput').value);
    const foodType = document.getElementById('foodTypeInput').value;
    const containsProtein = document.getElementById('containsProtein').checked;

    if (mealName && !isNaN(proteinAmount) && foodType) {
        const calories = proteinAmount * 4; // احتساب السعرات بناءً على البروتين (4 سعرات لكل جرام)
        mealRecords.push({ name: mealName, protein: proteinAmount, type: foodType, containsProtein, calories });
        localStorage.setItem('mealRecords', JSON.stringify(mealRecords));
        clearMealInputs();
        displayMealHistory();
        calculateTotalCalories();
        displayDailyStatus();
    } else {
        alert('يرجى إدخال بيانات صحيحة للوجبة.');
    }
}

// دالة لعرض سجل الوجبات
function displayMealHistory() {
    const historyDiv = document.getElementById('mealHistory');
    historyDiv.innerHTML = '<h3>سجل الوجبات:</h3>';

    mealRecords.forEach((record, index) => {
        const recordText = document.createElement('p');
        recordText.innerText = `${record.name} - بروتين: ${record.protein} جرام - نوع: ${record.type} - سعرات: ${record.calories}`;
        
        // زر للتعديل
        const editButton = document.createElement('button');
        editButton.innerText = 'تعديل';
        editButton.onclick = () => editMeal(index);
        
        // زر للحذف
        const deleteButton = document.createElement('button');
        deleteButton.innerText = 'حذف';
        deleteButton.onclick = () => deleteMeal(index);

        recordText.appendChild(editButton);
        recordText.appendChild(deleteButton);
        historyDiv.appendChild(recordText);
    });
}

// دالة لتعديل بيانات الوجبة
function editMeal(index) {
    const record = mealRecords[index];
    document.getElementById('mealInput').value = record.name;
    document.getElementById('proteinInput').value = record.protein;
    document.getElementById('foodTypeInput').value = record.type;
    document.getElementById('containsProtein').checked = record.containsProtein;

    mealRecords.splice(index, 1);
    localStorage.setItem('mealRecords', JSON.stringify(mealRecords));
    displayMealHistory();
    calculateTotalCalories();
}

// دالة لحذف سجل الوجبة
function deleteMeal(index) {
    mealRecords.splice(index, 1);
    localStorage.setItem('mealRecords', JSON.stringify(mealRecords));
    displayMealHistory();
    calculateTotalCalories();
}

// دالة لمسح المدخلات بعد الإغلاق
function clearMealInputs() {
    document.getElementById('mealInput').value = '';
    document.getElementById('proteinInput').value = '';
    document.getElementById('foodTypeInput').value = '';
    document.getElementById('containsProtein').checked = false;
}

// دالة لحساب مجموع السعرات اليومية
function calculateTotalCalories() {
    const totalCalories = mealRecords.reduce((sum, record) => sum + record.calories, 0);
    document.getElementById('totalCalories').innerText = `مجموع السعرات اليومية: ${totalCalories}`;
}

// دالة لإضافة بيانات التمارين
function addExerciseData() {
    const exerciseName = document.getElementById('exerciseInput').value;
    const duration = parseFloat(document.getElementById('durationInput').value);

    if (exerciseName && !isNaN(duration)) {
        exerciseRecords.push({ name: exerciseName, duration });
        localStorage.setItem('exerciseRecords', JSON.stringify(exerciseRecords));
        clearExerciseInputs();
        displayExerciseHistory();
        displayDailyStatus();
    } else {
        alert('يرجى إدخال بيانات صحيحة للتمرين.');
    }
}

// دالة لعرض سجل التمارين
function displayExerciseHistory() {
    const historyDiv = document.getElementById('exerciseHistory');
    historyDiv.innerHTML = '<h3>سجل التمارين:</h3>';

    exerciseRecords.forEach((record, index) => {
        const recordText = document.createElement('p');
        recordText.innerText = `${record.name} - مدة: ${record.duration} دقائق`;
        
        // زر للتعديل
        const editButton = document.createElement('button');
        editButton.innerText = 'تعديل';
        editButton.onclick = () => editExercise(index);
        
        // زر للحذف
        const deleteButton = document.createElement('button');
        deleteButton.innerText = 'حذف';
        deleteButton.onclick = () => deleteExercise(index);

        recordText.appendChild(editButton);
        recordText.appendChild(deleteButton);
        historyDiv.appendChild(recordText);
    });
}

// دالة لتعديل بيانات التمرين
function editExercise(index) {
    const record = exerciseRecords[index];
    document.getElementById('exerciseInput').value = record.name;
    document.getElementById('durationInput').value = record.duration;

    exerciseRecords.splice(index, 1);
    localStorage.setItem('exerciseRecords', JSON.stringify(exerciseRecords));
    displayExerciseHistory();
}

// دالة لحذف سجل التمرين
function deleteExercise(index) {
    exerciseRecords.splice(index, 1);
    localStorage.setItem('exerciseRecords', JSON.stringify(exerciseRecords));
    displayExerciseHistory();
}

// دالة لمسح المدخلات بعد الإغلاق
function clearExerciseInputs() {
    document.getElementById('exerciseInput').value = '';
    document.getElementById('durationInput').value = '';
}

// دالة لإضافة بيانات النوم
function addSleepData() {
    const sleepName = document.getElementById('sleepInput').value;
    const sleepStart = new Date(`1970-01-01T${document.getElementById('sleepStart').value}:00`);
    const sleepEnd = new Date(`1970-01-01T${document.getElementById('sleepEnd').value}:00`);
    const duration = (sleepEnd - sleepStart) / 60000; // تحويل المدة من مللي ثانية إلى دقائق

    if (sleepName && duration > 0) {
        sleepRecords.push({ name: sleepName, duration });
        localStorage.setItem('sleepRecords', JSON.stringify(sleepRecords));
        clearSleepInputs();
        displaySleepHistory();
        displayDailyStatus();
    } else {
        alert('يرجى إدخال بيانات صحيحة للنوم.');
    }
}

// دالة لعرض سجل النوم
function displaySleepHistory() {
    const historyDiv = document.getElementById('sleepHistory');
    historyDiv.innerHTML = '<h3>سجل النوم:</h3>';

    sleepRecords.forEach((record, index) => {
        const recordText = document.createElement('p');
        recordText.innerText = `${record.name} - مدة: ${record.duration} دقائق`;
        
        // زر للحذف
        const deleteButton = document.createElement('button');
        deleteButton.innerText = 'حذف';
        deleteButton.onclick = () => deleteSleep(index);

        recordText.appendChild(deleteButton);
        historyDiv.appendChild(recordText);
    });
}

// دالة لحذف سجل النوم
function deleteSleep(index) {
    sleepRecords.splice(index, 1);
    localStorage.setItem('sleepRecords', JSON.stringify(sleepRecords));
    displaySleepHistory();
}

// دالة لمسح المدخلات بعد الإغلاق
function clearSleepInputs() {
    document.getElementById('sleepInput').value = '';
    document.getElementById('sleepStart').value = '';
    document.getElementById('sleepEnd').value = '';
}

// دالة لتقييم حالة الوزن
function evaluateWeight() {
    const { weight, height } = userData;
    const bmi = (weight / ((height / 100) ** 2)).toFixed(2); // حساب مؤشر كتلة الجسم (BMI)

    let advice = '';
    if (bmi < 18.5) {
        advice = 'أنت تحت الوزن المثالي، حاول زيادة السعرات الحرارية وزيادة البروتين في نظامك الغذائي.';
    } else if (bmi >= 18.5 && bmi < 24.9) {
        advice = 'وزنك مثالي، حافظ على نظامك الغذائي المتوازن.';
    } else {
        advice = 'أنت فوق الوزن المثالي، حاول تقليل السعرات الحرارية وزيادة الخضروات والفواكه في نظامك الغذائي.';
    }

    document.getElementById('dailyStatus').innerHTML += `<p>تقييم الوزن: ${advice} (BMI: ${bmi})</p>`;
}

// دالة لعرض الحالة اليومية
function displayDailyStatus() {
    const statusDiv = document.getElementById('dailyStatus');
    const totalCalories = mealRecords.reduce((sum, record) => sum + record.calories, 0);
    const totalExerciseDuration = exerciseRecords.reduce((sum, record) => sum + record.duration, 0);
    const totalSleepDuration = sleepRecords.reduce((sum, record) => sum + record.duration, 0);

    statusDiv.innerHTML = `
        <p>مجموع السعرات اليومية: ${totalCalories}</p>
        <p>إجمالي مدة التمارين: ${totalExerciseDuration} دقائق</p>
        <p>إجمالي مدة النوم: ${totalSleepDuration} دقائق</p>
    `;

    evaluateWeight(); // تقييم الوزن بعد عرض الحالة اليومية
}
